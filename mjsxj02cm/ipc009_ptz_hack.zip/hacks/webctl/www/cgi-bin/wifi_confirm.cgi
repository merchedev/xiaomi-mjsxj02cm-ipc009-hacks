#!/bin/sh
mkdir -p /mnt/data/etc/webctl
touch /mnt/data/etc/webctl/confirm
echo "Content-Type: application/json"
echo ""
echo '{"ok":true,"message":"Подтверждено, откат отменён."}'
