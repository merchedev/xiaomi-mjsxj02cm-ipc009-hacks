#!/bin/sh
# Только чтение. Ничего не меняет в сети.
# Цель: собрать информацию, по которой можно будет безопасно добавить
# запись Wi-Fi/IP настроек (см. README.md).
echo "Content-Type: text/plain; charset=utf-8"
echo ""

echo "=== ip addr (wlan0) ==="
ip addr show wlan0 2>&1
echo

echo "=== ip route ==="
ip route 2>&1
echo

echo "=== ifconfig (fallback) ==="
ifconfig wlan0 2>&1
echo

echo "=== кандидаты конфигов Wi-Fi (только наличие) ==="
for f in /etc/wpa_supplicant.conf /mnt/data/etc/wpa_supplicant.conf \
         /tmp/wpa_supplicant.conf /etc/wireless/wpa_supplicant.conf \
         /mnt/data/miio/device.token /etc/miio/device.conf; do
	if [ -e "$f" ]; then
		echo "НАЙДЕН: $f"
	fi
done
echo

echo "=== процессы, связанные с сетью/облаком ==="
ps 2>&1 | grep -iE "wpa|dhcp|miio|mortox|network" | grep -v grep
echo

echo "=== os-release ==="
cat /mnt/data/etc/os-release 2>&1
