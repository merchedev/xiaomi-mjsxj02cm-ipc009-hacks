#!/bin/sh
echo "Content-Type: application/json"
echo ""
WPA=/mnt/data/wpa.conf
SSID=$(grep -m1 'ssid=' "$WPA" 2>/dev/null | sed 's/.*ssid="\(.*\)".*/\1/')
IP=$(ip -4 addr show wlan0 2>/dev/null | grep inet | awk '{print $2}' | cut -d/ -f1)
GW=$(ip route 2>/dev/null | grep default | awk '{print $3}')
echo "{\"ssid\":\"$SSID\",\"ip\":\"$IP\",\"gateway\":\"$GW\"}"
