#!/bin/sh
# Принимает форму (POST или GET) с ssid/psk/mode/ip/netmask/gateway/dns,
# сохраняет /mnt/data/etc/webctl/network.conf и запускает применение
# в фоне через wifi_manager.sh (с бэкапом и автооткатом).

CONF_DIR=/mnt/data/etc/webctl
NET_CONF="$CONF_DIR/network.conf"
MANAGER=/mnt/sdcard/hacks/webctl/bin/wifi_manager.sh
mkdir -p "$CONF_DIR"

if [ "$REQUEST_METHOD" = "POST" ] && [ -n "$CONTENT_LENGTH" ]; then
	BODY=$(dd bs=1 count="$CONTENT_LENGTH" 2>/dev/null)
else
	BODY="$QUERY_STRING"
fi

SSID=""; PSK=""; MODE="dhcp"; IP=""; NETMASK=""; GATEWAY=""; DNS=""
OLD_IFS="$IFS"
IFS='&'
for kv in $BODY; do
	key=${kv%%=*}
	val=${kv#*=}
	val=$(echo "$val" | sed 's/+/ /g; s/%\([0-9A-Fa-f][0-9A-Fa-f]\)/\\x\1/g')
	val=$(printf "$val")
	case "$key" in
		ssid) SSID="$val" ;;
		psk) PSK="$val" ;;
		mode) MODE="$val" ;;
		ip) IP="$val" ;;
		netmask) NETMASK="$val" ;;
		gateway) GATEWAY="$val" ;;
		dns) DNS="$val" ;;
	esac
done
IFS="$OLD_IFS"

echo "Content-Type: application/json"
echo ""

if [ -z "$SSID" ] || [ -z "$PSK" ]; then
	echo '{"ok":false,"error":"ssid and psk are required"}'
	exit 0
fi
if [ "$MODE" = "static" ] && { [ -z "$IP" ] || [ -z "$NETMASK" ] || [ -z "$GATEWAY" ]; }; then
	echo '{"ok":false,"error":"static mode requires ip, netmask and gateway"}'
	exit 0
fi

cat > "$NET_CONF" <<EOF2
SSID="$SSID"
PSK="$PSK"
MODE="$MODE"
IP="$IP"
NETMASK="$NETMASK"
GATEWAY="$GATEWAY"
DNS="$DNS"
EOF2

"$MANAGER" apply >/tmp/webctl_wifi_apply.log 2>&1 &

echo '{"ok":true,"message":"Применяется. Если у вас изменится IP/сеть, найдите камеру заново и в течение 90 секунд откройте эту страницу и нажмите Подтвердить — иначе будет автоматический откат к прежним настройкам."}'
