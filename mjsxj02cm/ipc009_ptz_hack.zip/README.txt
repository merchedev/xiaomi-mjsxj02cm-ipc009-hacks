Xiaomi MJSXJ02CM / IPC009 - optional PTZ and ONVIF add-on
=========================================================

This package adds pan/tilt control to the MJSXJ02CM / IPC009 camera without
using the Xiaomi cloud.

Contents
--------

  hacks/motor_control/     motord, event, status
  hacks/onvif_srvd/        ONVIF Profile S server and supervisor
  hacks/webctl/            optional web PTZ page on port 8081
  hacks/ptz.conf           PTZ direction configuration
  scripts/install_ptz_services.sh
  scripts/optimize_ram.sh

Install
-------

1. Install the base ipc009_hack.zip first.
2. Unzip this package to the root of the same SD card. Merge the hacks/ and
   scripts/ folders; do not replace the base hack.
3. Insert the card and boot the camera.
4. Log in over telnet as root (default password is empty).
5. Run:

     sh /mnt/sdcard/scripts/install_ptz_services.sh

   On 64 MB cameras, use:

     sh /mnt/sdcard/scripts/install_ptz_services.sh --optimize-ram

6. Wait 10-15 seconds and check:

     netstat -tln | grep -E ':(5000|8081|8554) '

7. Open http://<CAMERA_IP>:8081/ for the optional web PTZ page.
8. For Frigate or Home Assistant, add the ONVIF block:

     onvif:
       host: <CAMERA_IP>
       port: 5000
       user: admin
       password: admin

PTZ directions
--------------

The camera is often mounted upside down on a ceiling. The image flip is a
separate local setting:

     mortoxc set nvram default flip on

After the image flip, set the PTZ directions in hacks/ptz.conf:

     INVERT_PAN=1
     INVERT_TILT=1

Then restart the ONVIF service:

     /mnt/sdcard/hacks/runit/bin/sv down /mnt/data/etc/runit/onvif_srvd-run
     sleep 2
     killall onvif_srvd
     /mnt/sdcard/hacks/runit/bin/sv up /mnt/data/etc/runit/onvif_srvd-run

The web PTZ page reads ptz.conf automatically.

Documentation
-------------

  docs/09-onvif-ptz.md
  docs/10-flip.md
  docs/11-ram-optimization.md
  docs/12-wifi.md

Sources and credits
-------------------

  it-board.ru MJSXJ02CM ONVIF/RTSP guide (community install.zip)
  https://it-board.ru/raznoe/361-vosstanovlenie-i-pereproshivka-xiaomi-mi-home-security-camera-360-1080p-mjsxj02cm-na-onvif-rtsp.html

  onvif_srvd
  https://github.com/KoenVanDuffel/onvif_srvd

  tsunglung/xiaomi-360-hacks
  https://github.com/tsunglung/xiaomi-360-hacks

  Local miIO/PTZ context and flip prior art:
  https://github.com/666dsa666/mjsxj02cm-hacks

See THIRD_PARTY_NOTICES.md in the repository for licenses.

No personal data
----------------

This package contains no SSIDs, passwords, IP addresses, MAC addresses,
miIO tokens, camera serial numbers or recordings. Use placeholders in your
own notes.

This add-on is specific to the MJSXJ02CM / IPC009. Do not copy it to another
camera model.
